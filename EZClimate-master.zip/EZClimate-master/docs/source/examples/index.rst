Examples
========

Examples using the ezclimate package.


.. toctree::
	:maxdepth: 2
   
	output_paper
	
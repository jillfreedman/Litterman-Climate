import dlw 

tree =  dlw.tree.TreeModel(decision_times=[0, 15, 45, 85, 185, 285, 385])

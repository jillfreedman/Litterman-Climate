damage module
-------------

.. automodule:: ezclimate.damage
    :members:
    :undoc-members:
    :show-inheritance:
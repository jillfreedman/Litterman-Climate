cost module
-----------

.. automodule:: ezclimate.cost
    :members:
    :undoc-members:
    :show-inheritance:
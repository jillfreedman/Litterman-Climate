damage_simulation module
------------------------

.. automodule:: ezclimate.damage_simulation
    :members:
    :undoc-members:
    :show-inheritance:
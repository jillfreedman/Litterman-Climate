tree module
-----------

.. automodule:: ezclimate.tree
    :members:
    :undoc-members:
    :show-inheritance:
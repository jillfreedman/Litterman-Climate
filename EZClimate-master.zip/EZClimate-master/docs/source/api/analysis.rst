analysis module
---------------

.. automodule:: ezclimate.analysis
    :members:
    :undoc-members:
    :show-inheritance:
forcing module
--------------

.. automodule:: ezclimate.forcing
    :members:
    :undoc-members:
    :show-inheritance:
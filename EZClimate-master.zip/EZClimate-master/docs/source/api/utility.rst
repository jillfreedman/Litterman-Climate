utility module
--------------

.. automodule:: ezclimate.utility
    :members:
    :undoc-members:
    :show-inheritance:
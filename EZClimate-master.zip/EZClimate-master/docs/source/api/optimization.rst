optimization module
-------------------

.. automodule:: ezclimate.optimization
    :members:
    :undoc-members:
    :show-inheritance: